window.sr = ScrollReveal();
sr.reveal();
sr.reveal('.info-3', { duration: 2000, origin: "right", scale: 0, distance:"100px" }, 500);
sr.reveal('.intro-box', { duration: 1000, origin: "right", scale: 0, distance: "50px" }, 1000);
sr.reveal('.header-2', { duration:1000, origin: "right", scale: 0, distance: "50px" }, 300); 
sr.reveal('.header-3', { duration:1000, origin: "right", scale: 0, distance: "50px" }, 300); 
sr.reveal('.header-4', { duration:1000, origin: "right", scale: 0, distance: "50px" }, 300); 
sr.reveal('.form-intro', { duration:600, origin: "right", scale: 0, distance: "50px" }, 300); 